<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */

	public function __cunstruct()
	{

		parent::__cunstruct();
		$this->load->helper('form');
	    $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('session'); 
        $this->load->helper("file");
	}
	public function index()
	{

		$data['num_one'] = 0;
		$data['num_two'] = 0;
		$data['result'] = 0;
		$this->load->view('welcome_message',$data);
	}

	public function calculator()
	{

		$num_one=$this->input->get_post('num_one');
		$num_two=$this->input->get_post('num_two');
		$operator=$this->input->get_post('operator');

		if ($operator == 'Add') {
			$result = $num_one + $num_two;
		}elseif ($operator == 'Subtract') {
			$result = $num_one - $num_two;
		}elseif ($operator == 'Multiply') {
			$result = $num_one * $num_two;
		}elseif ($operator == 'Divide') {
			$result = $num_one / $num_two;
		}

		$data['num_one'] = $num_one;
		$data['num_two'] = $num_two;
		$data['result'] = $result;


		$this->load->view('welcome_message',$data);
	}
}
